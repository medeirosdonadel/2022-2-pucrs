import java.util.Scanner;

public class MeuMelhorPrograma {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        int milhar;
        int centena;
        int dezena;
        int unidade;

        System.out.print("Digite uma quantia inteira em R$ de 1 a 9999: ");
        milhar = in.nextInt();
        System.out.print("Digite uma quantia inteira em R$ de 1 a 9999: ");
        centena = in.nextInt();
        System.out.print("Digite uma quantia inteira em R$ de 1 a 9999: ");
        dezena = in.nextInt();
        System.out.print("Digite uma quantia inteira em R$ de 1 a 9999: ");
        unidade = in.nextInt();

        switch (milhar) {
            case 9:
                System.out.print("nove mil ");
                break;
            case 8:
                System.out.print("oito mil ");
                break;
            case 7:
                System.out.print("sete mil ");
                break;
            case 6:
                System.out.print("seis mil ");
                break;
            case 5:
                System.out.print("cinco mil ");
                break;
            case 4:
                System.out.print("quatro mil ");
                break;
            case 3:
                System.out.print("três mil ");
                break;
            case 2:
                System.out.print("dois mil ");
                break;
            case 1:
                System.out.print("mil ");
                break;
            default:
                System.out.println("Número inválido!");
                break;
        }
        switch (centena) {
            case 9:
                System.out.print("novecentos e ");
                break;
            case 8:
                System.out.print("oitocentos e ");
                break;
            case 7:
                System.out.print("setecentos e ");
                break;
            case 6:
                System.out.print("seiscentos e ");
                break;
            case 5:
                System.out.print("quinhetos e ");
                break;
            case 4:
                System.out.print("quatrocentos e ");
                break;
            case 3:
                System.out.print("trezentos e ");
                break;
            case 2:
                System.out.print("duzentos e ");
                break;
            case 1:
                System.out.print("cento e ");
                break;
            default:
                System.out.println("Número inválido!");
                break;

        }
        switch (dezena) {
            case 9:
                System.out.print("noventa e ");
                break;
            case 8:
                System.out.print("oitenta e ");
                break;
            case 7:
                System.out.print("setenta e ");
                break;
            case 6:
                System.out.print("sessenta e ");
                break;
            case 5:
                System.out.print("cinquenta e ");
                break;
            case 4:
                System.out.print("quarenta e ");
                break;
            case 3:
                System.out.print("trinta e ");
                break;
            case 2:
                System.out.print("vinte e ");
                break;
            case 1:
                System.out.print("dez");
                break;
            default:
                System.out.println("Número inválido!");
                break;

        }
        switch (unidade) {
            case 9:
                System.out.print("nove");
                break;
            case 8:
                System.out.print("oito");
                break;
            case 7:
                System.out.print("sete");
                break;
            case 6:
                System.out.print("seis");
                break;
            case 5:
                System.out.print("cinco");
                break;
            case 4:
                System.out.print("quatro");
                break;
            case 3:
                System.out.print("três");
                break;
            case 2:
                System.out.print("dois");
                break;
            case 1:
                System.out.print("um");
                break;
            default:
                System.out.println("Número inválido!");
                break;

        }
    }
}
/*Importa a classe Scanner da biblioteca Java.util.
Define uma classe chamada "ex2".
Define o método "main" que contém o código do programa.
Cria um objeto Scanner chamado "in" para ler a entrada do usuário.
Declara quatro variáveis do tipo inteiro: milhar, centena, dezena e unidade.
Exibe uma mensagem para o usuário digitar um valor entre 1 e 9999.
Lê o valor digitado pelo usuário e atribui à variável milhar.
Repete os passos 6 e 7 para ler os valores das variáveis centena, dezena e unidade.
Utiliza o comando switch-case para selecionar a palavra correspondente a milhar e exibi-la na tela.
Utiliza o comando switch-case para selecionar a palavra correspondente a centena e exibi-la na tela, juntamente com a palavra "e".
Utiliza o comando switch-case para selecionar a palavra correspondente a dezena e exibi-la na tela, juntamente com a palavra "e", exceto se a dezena for 1, quando a palavra "dez" é exibida sem a palavra "e".
Utiliza o comando switch-case para selecionar a palavra correspondente a unidade e exibi-la na tela.
O programa termina. */