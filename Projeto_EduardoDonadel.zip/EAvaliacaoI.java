import java.util.Scanner;

public class EAvaliacaoI {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        double numApartamentos, valorDiaria, valorPromococional, valor100, valor70;

        System.out.println("Número de apartamentos do hotel: ");
        numApartamentos = in.nextDouble();
        System.out.println("Valor da diaria: ");
        valorDiaria = in.nextDouble();
        
    
        double valorPromocional = valorDiaria * 0.75;
        double valorArrecadadoTotal = numApartamentos * valorDiaria;
        double valorArrecadado70 = numApartamentos * valorPromocional * 0.7;
        double valorDeixadoDeArrecadar = valorArrecadadoTotal - (numApartamentos * valorPromocional);

        System.out.println("\nValor promocional da diária: " + valorPromocional);
        System.out.println("Valor total a ser arrecadado com 100% de ocupação: " + valorArrecadadoTotal);
        System.out.println("Valor total a ser arrecadado com 70% de ocupação: " + valorArrecadado70);
        System.out.println("Valor que o hotel deixará de arrecadar em virtude da promoção: " + valorDeixadoDeArrecadar);

    }
    
}
