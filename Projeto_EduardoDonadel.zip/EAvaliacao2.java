package Semana5.segunda;

import java.util.Scanner;

public class EAvaliacao2 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Digite a temperatua: ");
        double temp = in.nextDouble();

        System.out.println("1 para Celsius, 2 para Fahrenheit.");
        double valor = in.nextDouble();

        if (valor == 1) {
            if (temp > 100) {
                System.out.println("Água no estado gasoso.");
            } else if (temp < 0) {
                System.out.println("Água no estado sólido.");
            } else {
                System.out.println("Água no estado líquido");
            }
        }
        else if (valor == 2) {
            if (temp > 212) {
                System.out.println("Água no estado gasoso.");
            } else if (temp < 32) {
                System.out.println("Água no estado sólido.");
            } else {
                System.out.println("Água no estado líquido");
            }

        }
        else {
            System.out.println("Erro");
        }
        

    }

}
